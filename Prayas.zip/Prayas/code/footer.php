<section class="footer">

    <div class="box-container">

        <div class="box">
            <h3>Quick Links</h3>
            <a href="home.php">Home</a>
            <a href="about.php">About</a>
            <a href="contact.php">Contact</a>
            <a href="shop.php">Shop</a>
        </div>

        <div class="box">
            <h3>Extra Links</h3>
            <a href="login.php">Login</a>
            <a href="register.php">Register</a>
            <a href="orders.php">My Orders</a>
            <a href="cart.php">My Cart</a>
        </div>

        <div class="box">
            <h3>Contact Info</h3>
            <!-- <p> <i class="fas fa-phone"></i> +91 9909956893 </p>
            <p> <i class="fas fa-phone"></i> +91 9979469006 </p> -->
            <p> <a title="Whatsapp"  target="_blank" href="https://wa.me/919909956893?text=Hello%20I have%20Query"><i class="fas fa-phone"></i>+91 9909956893</a></p>
            <p> <a title="Whatsapp"  target="_blank" href="https://wa.me/919979469006?text=Hello%20I have%20Query"><i class="fas fa-phone"></i>+91 9979469006</a></p>
            <p> <a title="Whatsapp"  target="_blank" href="https://wa.me/918799565994?text=Hello%20I have%20Query"><i class="fas fa-phone"></i>+91 8799565994</a></p>
            <!-- <p> <i class="fas fa-envelope"></i> prayasenterprise7678@gmail.com </p> -->
            <p> <i class="fas fa-envelope"></i> Email-ID: -<a style='text-decoration: none' target='_blank' href='mailto:pratasenterprise7678@gmail.com?cc=prayasenterprise7678@gmail.com&bcc=prayasenterprise7678@gmail.com'>prayasenterprise7678@gmail.com </a></p>
            <p> <i class="fas fa-map-marker-alt"></i> PRAYAS ENTERPRISE, Gautam-2, Shop No-1, Nr. Sant Krupa Granite, Manharpur-1, Madhapar Circle, Jamnagar Road, Rajkot-360006.  </p>
        </div>

        <div class="box">
            <h3>Follow Us</h3>
            <a href="#"><i class="fab fa-facebook-f"></i>Facebook</a>
            <a href="https://instagram.com/prayas__enterprise_?igshid=YmMyMTA2M2Y="><i class="fab fa-instagram"></i>Instagram</a>
        </div>

    </div>

    <div class="credit">&copy; Copyright @ <?php echo date('Y'); ?> by <span>V-Crush Oil</span> </div>

</section>